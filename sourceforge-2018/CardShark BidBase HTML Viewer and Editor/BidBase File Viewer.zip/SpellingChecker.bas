Attribute VB_Name = "basSpellingChecker"
Option Explicit

Public CortexWS As Workspace
Public CortexDB As Database
Public CortexRS As Recordset
Public Cortex2RS As Recordset
Public Cortex3RS As Recordset
'Public WordsRS As Recordset

Public AICWordsWS As Workspace
Public AICWordsDB As Database
Public WordsRS As Recordset

Dim LinkTypeRS As Recordset
Dim SyllRS As Recordset
Dim PrnRS As Recordset
Dim MobyRS As Recordset
Dim CmuRS As Recordset
Dim BrownFreqRS As Recordset
Dim WebFreqRS As Recordset
Dim SpellRS As Recordset
Dim NumbersRS As Recordset
Dim WikiSpellRS As Recordset
Dim WordFreqRS As Recordset

Dim DefsWS As Workspace
Dim DefsDB As Database
Dim DefsRS As Recordset
Private str_Word As String
Private str_User As String
Private str_IgnoreWords(1000) As String
Private int_LastIgnore As Integer
Public bln_CheckWord As Boolean
Public HighlightLen As Long
Public HighlightStart As Long

Public int_Nested As Boolean
Public long_WordID As Long
Public long_CortexID As Long


Public Sub AddWord(ByVal str_Word As String)
    Dim i As Long
    Dim s As String
    
    str_Word = Trim$(str_Word)
    If str_Word = "" Then Exit Sub

    With BidBaseFileViewer.lstSuggestions2
        ' a sorted list box not being used '
        For i = 1 To Len(str_Word)
            .AddItem Mid$(str_Word, i, 1)
        Next
        ' The letters are now in sorted order. '
        For i = 0 To Len(str_Word) - 1
            s = s & .List(i)
        Next
    End With
    
    On Local Error GoTo AddError
    With WordsRS
        .index = "ID"
        .MoveLast
        i = !Id + 1
        .AddNew
        !Id = i
        !Text = str_Word
        !Soundex = Soundex(str_Word)
        !Tag = 999
        !Sorted = s
        .Update
        long_WordID = !Id
    End With

AddError:
    If Err.Number > 0 Then
        MsgBox "Error #" & Err.Number & " while saving " & str_Word
        Err.Clear
    End If
    On Local Error GoTo 0
End Sub


Public Sub ClearSpellCheckBox( _
        ByVal str_Word As String)

    With BidBaseFileViewer
        .lstSuggestions.Clear
        .t_Replace = ""
        .t_Word = str_Word
    End With

End Sub


Public Sub CloseSpellCheck()
    On Local Error Resume Next
    WordsRS.Close
    LinkTypeRS.Close
    SyllRS.Close
    PrnRS.Close
    SpellRS.Close
    NumbersRS.Close
    Cortex3RS.Close
    Cortex2RS.Close
    WikiSpellRS.Close
    CortexRS.Close
    CortexDB.Close
    CortexWS.Close
    AICWordsDB.Close
    AICWordsWS.Close

    With BidBaseFileViewer
        .t_Word = ""
        .t_Replace = ""
        .lstSuggestions.Clear
        .Text2(1).SelColor = vbBlack
        .Text2(1).SelBold = False
    End With

    If Not bln_CheckWord Then
        MsgBox "Spell-check is completed."
    Else
        bln_CheckWord = False
    End If
    
    On Local Error GoTo 0
    Erase str_IgnoreWords
    BidBaseFileViewer.HideSuggestionBox
End Sub


Public Sub GetSuggestions( _
            ByVal str_Word As String, _
            ByVal sndx As String)
    Dim n As Integer
    Dim L As Integer
    Dim best As Integer
    Dim lev As Integer
    Dim i As Integer
    Dim j As Integer
    Dim K As Integer
    Dim tst1 As Integer
    Dim tst2 As Integer
    Dim tst3 As Integer
    Dim tst4 As Integer
    Dim sndx2 As String
    Dim w2 As String
    Dim w3 As String
    Dim cons As String
    Dim cons2 As String
    Dim c1 As String
    Dim c2 As String
    Dim keys(4) As String
    Dim roW As Long
    Dim col As Long
    Dim adjacent As Boolean
    Dim got1 As Boolean
    Dim wID As Long
    Dim q As Long
    Dim sug(1000) As String
    Dim capWord As String
    Dim tempWord As String
    Dim z As Long
    Dim runOnWords() As String
    Dim s As String
    
    If Len(str_Word) < 2 Then Exit Sub
    
    ' An idea I haven't implemented is to take the  '
    ' top suggestions from the initial analysis and '
    ' run this routine on them, then do a LevDist   '
    ' analysis on each of the results compared to   '
    ' the original input.  What prompted this is    '
    ' that someone entered "resind" for "resigned", '
    ' which did not come up as a suggestion, but    '
    ' taking one of the other top suggestions for   '
    ' "resind" and analyzing it, "resigned" did     '
    ' come up. The problem is that missing letters  '
    ' are hard to figure out, and resind has two,   '
    ' so maybe it takes two runs to find it.        '
    
    BidBaseFileViewer.lstSuggestions2.Clear
'    BidBaseFileViewer.lstSuggestions2.Visible = True

    ' Convert the word to just consonants: '
    cons = Replace$(LCase$(str_Word), "a", "")
    cons = Replace$(LCase$(cons), "e", "")
    cons = Replace$(LCase$(cons), "i", "")
    cons = Replace$(LCase$(cons), "o", "")
    cons = Replace$(LCase$(cons), "u", "")
    
    With WordsRS
        ' Swap out each letter and look for words: '
        .index = "Text"
        K = Len(str_Word)
        For i = 1 To K
            w2 = str_Word
            c1 = Mid$(w2, i, 1)
            z = Asc(c1)
            For j = 97 To 122
                If j <> z Then
                    Mid$(w2, i, 1) = Chr$(j)
                    .Seek "=", w2
                    If Not .NoMatch Then
                        ' Because searches are not case sensitive, '
                        ' this will get matches regardless of case.'
                        BidBaseFileViewer.lstSuggestions2.AddItem !Text
                    End If
                End If
            Next
        Next
    
        ' Get words with same Soundex code as target word. '
        .index = "Soundex"
        .Seek "=", sndx
        If Not .NoMatch Then
            CortexRS.index = "WordID"
            CortexRS.Seek "=", !Id
            If Not CortexRS.NoMatch Then
              If CortexRS!LinkID = 31015 Or CortexRS!LinkID = 31040 Then
                ' Word entered is misspelled. '
                ' StartID should contain the  '
                ' cID entry for the real word.'
                If Not IsNull(CortexRS!startID) Then
                    wID = CortexRS!startID
                    CortexRS.index = "ID"
                    CortexRS.Seek "=", wID
                    If CortexRS.NoMatch Then Stop
                    If IsNull(CortexRS!WordID) Then Stop
                    .index = "ID"
                    wID = CortexRS!WordID
                    .Seek "=", wID
                    'If .NoMatch Then Stop
                    BidBaseFileViewer.lstSuggestions.AddItem WordsRS!Text
                    BidBaseFileViewer.t_Replace = WordsRS!Text
                    Exit Sub
                End If
              End If
            End If
            
            Do While !Soundex = sndx
                BidBaseFileViewer.lstSuggestions2.AddItem !Text
                .MoveNext
                If .NoMatch Then
                    Exit Do
                End If
            Loop
        End If
        
        ' Look at code to see if digits are reversed. '
        ' Example: silibant = S415, sibilant = S145   '
        ' Swap first two digits (e.g.: 41 -> 14):     '
        w2 = sndx
        c2 = Mid$(w2, 2, 1)
        Mid$(w2, 2, 2) = Mid$(w2, 3, 1) & c2
        .Seek ">=", w2
        If Not .NoMatch Then
            Do While Left$(!Soundex, Len(w2)) = w2
                BidBaseFileViewer.lstSuggestions2.AddItem !Text
                .MoveNext
                If .EOF Then Exit Do
            Loop
        End If
        
        ' Swap 2nd-3rd digits (e.g.: 15 -> 51): '
        w2 = sndx
        c2 = Mid$(w2, 3, 1)
        If Not (Mid$(w2, 4, 1) = "0" And c2 = "0") Then
            ' Don't swap one 0 for another. '
            Mid$(w2, 3, 2) = Mid$(w2, 4, 1) & c2
            .Seek ">=", w2
            If Not .NoMatch Then
                Do While !Soundex = w2
                    BidBaseFileViewer.lstSuggestions2.AddItem !Text
                    .MoveNext
                    If .EOF Then Exit Do
                Loop
            End If
        End If
        
        ' Search for some other words '
        ' not indicated by Soundex:   '
        
        ' See if text is a run-on word: '
        If Len(str_Word) > 3 Then
            int_Nested = 0
            FindRunOns str_Word, ""
        End If
        
        ' Typos:                                    '
        ' There are three kinds:                    '
        ' 1. hit key adjacent AND the target key.   '
        '       Example:  phjone  ->  phone         '
        '       (Could be same key twice:  phoone)  '
        ' 2. hit an adjacent key instead of target. '
        '       Example:  ohone  ->  phone          '
        ' 3. left out the intended letter.          '
        '       Example:  phne  ->  phone           '
        '                                           '
        ' For each letter in the submitted word,    '
        ' check to see if the next letter is adja-  '
        ' cent to it. If so, assume that it is a    '
        ' Type 1 error (e.g.: "j" is adjacent to "h")
        ' Take out the current letter (j) and search'
        ' for a match in the dictionary. Note that  '
        ' the target letter could have been hit     '
        ' twice, such as "phoone", so test it too.  '
        '                                           '
        ' If the current letter is NOT adjacent to  '
        ' the next letter, assume it is a Type 2    '
        ' error (e.g.: "o" is not adjacent to "h"). '
        ' Substitute for the current letter ("o")   '
        ' each of the letters around that letter    '
        ' (e.g.: i, k, l, p) and check for words in '
        ' the dictionary.                           '
        '                                           '
        ' Note that we have to test each letter of  '
        ' the submitted word. Even if we find a good'
        ' word, there may be another/more.          '
        
        keys(0) = "            "
        keys(1) = " qwertyuiop "
        keys(2) = " asdfghjkl  "
        keys(3) = " zxcvbnm    "
        keys(4) = "            "
        
        ' Check for dropped first letter: '
        For j = 97 To 122 ' a - z '
            w2 = Chr$(j) & str_Word
            .Seek "=", w2
            If Not .NoMatch Then
                BidBaseFileViewer.lstSuggestions2.AddItem w2
                got1 = True
            End If
        Next

        For i = 1 To Len(str_Word)
            c1 = LCase$(Mid$(str_Word, i, 1))
            c2 = LCase$(Mid$(str_Word, i + 1, 1))
            
            If c2 = "'" And Right$("  " & str_Word, 3) = "in'" And i = j Then
                ' e.g.:  runnin'  '
                w2 = ChopRight(str_Word, 1) & "g"
                .Seek "=", w2
                If Not .NoMatch Then
                    BidBaseFileViewer.lstSuggestions2.AddItem w2
                    got1 = True
                End If
            End If
            
            If c2 = "-" Then Exit For
            If c2 > "z" Then Stop: Exit For
            col = InStr(keys(1), c2)
            If col > 0 Then
                roW = 1
            Else
                col = InStr(keys(2), c2)
                If col > 0 Then
                    roW = 2
                Else
                    col = InStr(keys(3), c2)
                    roW = 3
                End If
            End If
                    
            ' Is first char adjacent to the 2nd char? '
            ' Example:  "phjone"                      '
            adjacent = False
            For j = -1 To 1 ' row '
                For K = 0 To 2 ' col '
                    If Mid$(keys(roW + j), col + K, 1) = c1 Then
                        ' First char is adjacent to 2nd.  '
                        ' If this is a typo, c1 is likely '
                        ' an added character. Try leaving '
                        ' it out and look for the word:   '
                        adjacent = True
                    End If
                    
                    ' Do this for each letter in the word, '
                    ' not just adjacent ones:              '
                    ' (It doesn't take noticeably longer.) '
                    w2 = Left$(str_Word, i - 1) & Mid$(str_Word, i + 1)
                    .Seek "=", w2
                    If Not .NoMatch Then
                        Do While !Text <> w2 And LCase$(!Text) = LCase$(w2)
                            .MoveNext
                            If .EOF Then Exit Do
                        Loop
                        If !Text = w2 Then
                            BidBaseFileViewer.lstSuggestions2.AddItem w2
                            got1 = True
                        End If
                    End If
                Next
            Next
            
            If Not adjacent Then
                ' Not adjacent, so it is more likely '
                ' a substitution of a letter than an '
                ' addition of a letter. Try swapping '
                ' the letters adjacent to c1.        '
                ' Example: ohone  swap i,k,l,p for o '
                col = InStr(keys(1), c1)
                If col > 0 Then
                    roW = 1
                Else
                    col = InStr(keys(2), c1)
                    If col > 0 Then
                        roW = 2
                    Else
                        col = InStr(keys(3), c1)
                        roW = 3
                    End If
                End If
                
                For j = -1 To 1
                    If roW + j = 0 Then j = 0 ' row 0 is blank '
                    For K = -1 To 1
                        w2 = str_Word
                        c2 = Mid$(keys(roW + j), col + K, 1)
                        If c2 <> " " Then
                            Mid$(w2, i, 1) = Mid$(keys(roW + j), col + K, 1)
                            .Seek "=", w2
                            If Not .NoMatch Then
                                Do While !Text <> w2 And LCase$(!Text) = LCase$(w2)
                                    .MoveNext
                                    If .EOF Then Exit Do
                                Loop
                                If !Text = w2 Then
                                    BidBaseFileViewer.lstSuggestions2.AddItem w2
                                    got1 = True
                                End If
                            End If
                        End If
                    Next
                    If roW + j = 3 Then Exit For ' row 4 is blank '
                Next
            End If
        
            ' Swap c1 and c2 and look for a word. '
            ' Example:  ocme  ->  come            '
            w2 = str_Word
            Mid$(w2, i, 2) = Mid$(w2, i + 1, 1) & Mid$(w2, i, 1)
            .Seek "=", w2
            If Not .NoMatch Then
                Do While !Text <> w2 And LCase$(!Text) = LCase$(w2)
                    .MoveNext
                    If .EOF Then Exit Do
                Loop
                If !Text = w2 Then
                    BidBaseFileViewer.lstSuggestions2.AddItem w2
                    got1 = True
                End If
            End If
            
            ' Look for dropped letters:        '
            ' "wite" was not showing "write"   '
            ' "nventory" -- "inventory",       '
            ' "icluding" -- "including", etc.  '
            If i < Len(str_Word) Then
                w3 = str_Word
                If Mid$(str_Word, i, 1) = "'" Then
                    w3 = Left$(w3, i - 1) & Mid$(w3, i + 1)
                End If
                ' The above changes 'bout to just bout  '
                ' then the following routine checks for '
                ' the missing letter. Likewise for words'
                ' like acc'racy.                        '
                
                For j = 97 To 122  ' a - z '
                    w2 = Left$(w3, i) & Chr$(j) & Mid$(w3, i + 1)
                    .Seek "=", w2
                    If .NoMatch Then
                        If i = 1 Then
                            w2 = Chr$(j) & w3
                        Else
                            w2 = Left$(w3, i - 1) & Chr$(j) & Mid$(w3, i)
                        End If
                        .Seek "=", w2
                    End If
                    
                    If Not .NoMatch Then
                        Do While !Text <> w2 And LCase$(!Text) = LCase$(w2)
                            .MoveNext
                            If .EOF Then Exit Do
                        Loop
                        If !Text = w2 Then
                            BidBaseFileViewer.lstSuggestions2.AddItem w2
                            got1 = True
                        End If
                    End If
                Next
            End If
        Next

        ' Look for dropped letter at end of word:            '
        ' Not sure if this is needed, but doesn't take long. '
        For j = 97 To 122  ' a - z '
            w2 = str_Word & Chr$(j)
            .Seek "=", w2
            If Not .NoMatch Then
                Do While !Text <> w2 And LCase$(!Text) = LCase$(w2)
                    .MoveNext
                    If .EOF Then Exit Do
                Loop
                If !Text = w2 Then
                    BidBaseFileViewer.lstSuggestions2.AddItem w2
                    got1 = True
                End If
            End If
        Next
        
        ' Check input starting with non '
        ' and followed by good words.   '
        ' ex: nontoxic - look for toxic '
        If Left$(str_Word & "  ", 3) = "non" Then
            w2 = Mid$(str_Word, 4)
            .index = "Text"
            .Seek "=", w2
            If Not .NoMatch Then
                BidBaseFileViewer.lstSuggestions2.AddItem "non" & w2
            End If
        End If
        
        ' The syllable -tu- is pronounced "chEW" '
        ' (taran-tu-la, even-tu-al) which may    '
        ' lead people to spell the word that way '
        ' (taran-chu-la). So try swapping -chu-  '
        ' for -tu- and looking for a word. (This '
        ' is off-base for words where chu is not '
        ' a stand-alone syllable, but it doesn't '
        ' cost much time to try it.)             '
        ' Others: ritual (rich-EW-EHl)           '
        '         actual (ak'chEW-EHl)           '
        '      punctuation (pungk'chEW-AE'shEHn) '
        i = InStr(str_Word, "chu")
        If i > 0 Then
            w2 = Replace$(str_Word, "chu", "tu")
            .index = "Text"
            .Seek "=", w2
            If Not .NoMatch Then
                BidBaseFileViewer.lstSuggestions2.AddItem w2
            End If
        End If
    
    End With
    
' Filter suggestions to get reasonable matches: '
    With BidBaseFileViewer.lstSuggestions2
        If .ListCount > 0 Then
            ReDim scores(1, .ListCount - 1) As Integer
            ReDim hiQ(1) As Integer
            i = 0
            ' Remove duplicates: '
            Do While i < .ListCount - 1
                Do While .List(i) = .List(i + 1)
                    .RemoveItem i
                Loop
                i = i + 1
            Loop
            
            If .ListCount = 0 Then
                GoTo WikiList
            End If
            
            i = 0
            Do While i < .ListCount
                w3 = .List(i)

                Do While InStr(.List(i), " ") > 0
                    i = i + 1
                    If i = .ListCount Then Exit Do
                Loop
                If i = .ListCount Then Exit Do

                If Abs(Len(str_Word) - Len(w3)) > 2 Then
                    scores(0, i) = 0
                    scores(1, i) = 0
                Else
                    scores(0, i) = qGram(str_Word, w3) _
                                   - Abs(Len(str_Word) _
                                   - Len(w2))
                    scores(1, i) = nGram(str_Word, w3)
                End If

                For j = 0 To 1
                    If scores(j, i) > hiQ(j) Then
                        hiQ(j) = scores(j, i)
                    End If
                Next
                i = i + 1
            Loop

            n = .ListCount - 1
            For i = n To 0 Step -1
                sug(i) = .List(i)
                Do While InStr(.List(i), " ") > 0
                    sug(i) = .List(i)
                    i = i - 1
                    If i < 0 Then Exit For
                Loop

                If sug(i) <> "zzzz" And scores(0, i) > 0 And _
                   (scores(1, i) > 0 Or _
                    Len(str_Word) < 4) _
                Then
                    tst1 = Len(str_Word) > 4 And _
                           hiQ(0) - scores(0, i) > 2
            
                    tst2 = Len(str_Word) > 2 And _
                           Len(str_Word) < 5
                
                    tst3 = scores(0, i) < 2
                
                    tst4 = hiQ(1) - scores(1, i) > 1 And _
                       Len(str_Word) - hiQ(1) < 4
                
                    cons2 = Replace$(sug(i), "a", "")
                    If Right$(cons2, 2) = "gn" Then cons2 = Left$(cons2, Len(cons2) - 2) & "n"
                    cons2 = Replace$(cons2, "e", "")
                    cons2 = Replace$(cons2, "i", "")
                    cons2 = Replace$(cons2, "o", "")
                    cons2 = Replace$(cons2, "u", "")

                    If (tst1 And tst2 And tst3) Or _
                       tst4 Or _
                       Abs(Len(str_Word) - Len(w3)) > 2 _
                    Then
                        K = LevDist(str_Word, sug(i))
                        If LCase$(cons) <> LCase$(cons2) And K > 2 Then
                            ' This was removing "alright" from "all right" '
                            ' so I put in the LevDist check.               '
                            sug(i) = "zzzz"
                        End If
                    End If
                ElseIf i < .ListCount And str_Word <> Replace$(sug(i), "-", "") And str_Word <> Replace$(sug(i), "'", "") Then
                    sug(i) = "zzzz"
                End If
            Next
        End If
        
        .Clear
        j = 0
        Do
            If sug(j) <> "zzzz" Then .AddItem sug(j)
            j = j + 1
        Loop While sug(j) <> "" Or j < n
        
        Do While .List(0) = "" And .ListCount > 0
            .RemoveItem 0
        Loop
        
        ' Move the top suggestion to the top of the list: '
        If .ListCount > 0 Then
            ' Find word in list of about the same  '
            ' length with the most matching letters:
            lev = 999
            n = 0
            
            Do
                w3 = .List(n)
                .RemoveItem n

                If Abs(Len(str_Word) - Len(w3)) < 3 Or InStr(w3, " ") > 0 Then
                    If InStr(w3, " ") > 0 Then
                        ' Split up a run-on word. '
                        ' Make it go after after  '
                        ' non-split words with 1. '
                        .AddItem "2 - " & w3
                    Else
                        If str_Word = w3 Then
                            L = 0
                        Else
                            L = LevDist(str_Word, w3)
                        End If
                        
                        If L < 4 Then ' Don't show words with LevDist > 3. '
                            FindWordID w3 ' sets long_WordID '
                            FindWordIDEntry w3, long_WordID ' sets long_CortexID '
                    
                            If long_CortexID = 0 Then
                                w3 = w3 & " (Not in Cortex.)"
                            '    Stop
                            End If
                            
                            .AddItem L & " - " & w3
                    
                            If L < lev Then lev = L
                        End If
                    End If
                End If
                        
                If Val(.List(n)) > 0 Then n = n + 1
            Loop While n < .ListCount
        End If
    End With
    
WikiList:
    ' Look in Wikipedia's list of common misspellings: '
    With WikiSpellRS
        .index = "Wrong"
        .Seek "=", str_Word
        If Not .NoMatch Then
            Do
                w3 = !Right
                BidBaseFileViewer.lstSuggestions2.AddItem "0 - " & w3 & " (WikiSpell table)", 0
                .MoveNext
            Loop While !Right = w3
        End If
    End With
    
    
    ' I'm not getting "repertoire" as '
    ' a suggestion for "repetoir"     '
    ' because 2 letters are missing.  '
    ' This is a heavy-handed attempt  '
    ' to find such a match, but the   '
    ' results are still virtually     '
    ' instantaneous.                  '
    With WordsRS
        If Len(str_Word) > 5 And Val(BidBaseFileViewer.lstSuggestions2.List(0)) > 1 Then
            ' This is an arbitrary range, '
            ' but I think it is probably  '
            ' needed more for longer words.
            ' Skip this if we already have'
            ' a 1 on the list.            '
            w2 = Left$(str_Word, 3)
            .Seek ">=", w2
            If Not .NoMatch Then
                Do
                    i = LevDist(str_Word, !Text)
                    If i < 3 Then ' arbitrary '
                        BidBaseFileViewer.lstSuggestions2.AddItem i & " - " & !Text
                    End If
                    .MoveNext
                    If .EOF Then Exit Do
                Loop While w2 = Left$(LCase$(!Text), 3)
                
                ' Remove duplicates: '
                i = 0
                Do While i < BidBaseFileViewer.lstSuggestions2.ListCount - 1
                    Do While Replace$(BidBaseFileViewer.lstSuggestions2.List(i), " (Not in Cortex.)", "") = Replace$(BidBaseFileViewer.lstSuggestions2.List(i + 1), " (Not in Cortex.)", "")
                        BidBaseFileViewer.lstSuggestions2.RemoveItem i
                    Loop
                    i = i + 1
                Loop
            End If
        End If
    End With
    
    ' Add word frequency ranking to the list: '
    n = BidBaseFileViewer.lstSuggestions2.ListCount - 1
    sug(0) = ""
    With WordsRS 'WordFreqRS
        '.Index = "Word"
        WordsRS.index = "Text"
        For i = 0 To n
            sug(i) = BidBaseFileViewer.lstSuggestions2.List(i)
            j = Val(sug(i))

                w3 = Mid$(sug(i), 5)
                
                z = InStr(w3, " (")
                If z > 0 Then
                    s = Mid$(w3, z)
                    w3 = Left$(w3, z - 1)
                Else
                    s = ""
                End If
                
                If InStr(w3, " ") = 0 Then
                    .Seek "=", w3
                        
                    If Not WordsRS.NoMatch Then
                        If WordsRS!Text <> w3 Then WordsRS.MoveNext
                        K = WordsRS!Text <> w3
                    Else
                        K = 0
                    End If
                        
                    If WordsRS.NoMatch Or K Or IsNull(WordsRS!FreqUsed) Then
                        sug(i) = j & " (_) - " & w3
                    ElseIf WordsRS!FreqUsed < "4" Then
                        sug(i) = j & " (" & WordsRS!FreqUsed & ") - " & w3
                    Else
                        sug(i) = ""
                    End If
                    
                    If sug(i) <> "" Then sug(i) = sug(i) & s
                Else
                    ' Run-on word splits: '
                    'sug(i) = "2 (_) - " & w3
                    runOnWords = Split(w3)
                    'Stop
                End If
        Next
    End With
    
    With BidBaseFileViewer.lstSuggestions2
        .Clear
        
        For i = 0 To n
            If sug(i) <> "" Then
                .AddItem sug(i)
            End If
        Next
        
        If .ListCount = 0 Then
            Exit Sub
        End If
        
        ' Easiest way to get words with '
        ' no freq ranking to the bottom.'
        For i = 0 To n + 2
            w3 = .List(i)
            n = Val(w3)
            
                ' A suggestion with all consonants the  '
                ' same as the input text is more likely '
                ' to be correct. Example: "flowerey"    '
                ' floweret and flowery both = 1 change, '
                ' but flowery has the same consonants.  '
                If Val(Left$(w3, 1)) = n Then
                    cons2 = Mid$(w3, 13)
                    j = InStr(cons2, " (")
                    If j > 0 Then cons2 = Left$(cons2, j - 1)
                    cons2 = Replace$(cons2, "a", "")
                    cons2 = Replace$(cons2, "e", "")
                    cons2 = Replace$(cons2, "i", "")
                    cons2 = Replace$(cons2, "o", "")
                    cons2 = Replace$(cons2, "u", "")
                    j = InStr(cons2, " (")
                    If j > 0 Then cons2 = Left$(cons2, j - 1)
                    If cons = cons2 Then
                        .RemoveItem i
                        j = i
                        Do While Val(Left$(.List(j - 1), 1)) = Val(Left$(w3, 1)) And j > 2
                            j = j - 1
                        Loop
                        .AddItem w3, j
                    End If
                End If
        Next
                        
        For i = 0 To .ListCount - 1
            w3 = .List(i)
            w3 = Replace(w3, " (Not in Cortex.)", "")
            j = InStr(w3, "-")
            ' Put in the visible list: '
            BidBaseFileViewer.lstSuggestions.List(i) = Mid$(w3, j + 2)
        Next
        
    End With
End Sub

Private Function ChopRight(w As String, n As Integer) As String
    If w <> "" Then ChopRight = Left$(w, Len(w) - n)
End Function



Sub FindWordID(w As String)
    Dim i As Integer

    With WordsRS
    '''''''''''
    .index = "Text"
    .Seek "=", w
    If .NoMatch = False Then
        Do While !Text <> w And LCase$(!Text) = LCase$(w)
            ' Upper/lowercase don't match '
            .MoveNext
            If .EOF Then long_WordID = 0: Exit Sub
        Loop
        If !Text = w Then
            long_WordID = !Id
        Else
            .Seek "=", w
            If .NoMatch Then
                long_WordID = 0
            Else
                long_WordID = !Id
                w = !Text
            End If
        End If
    Else
        long_WordID = 0
    End If
    ''''''''
    End With
End Sub


Private Sub FindWordIDEntry(w As String, n As Long)
    With CortexRS
        .index = "WordID"
        .Seek "=", n
        If .NoMatch Then
            long_CortexID = 0
            Exit Sub
        Else
            long_CortexID = !Id
        End If
    End With
End Sub


Public Sub FindRunOns(runOnWords As String, splitWords As String)
    ' Take text like "fillitup" and split it into "fill it up". '
    Dim i As Long
    Dim j As Long
    Dim K As Long
    Dim rank As Long
    Dim splitPoint As Long
    Dim wrdLen As Long
    Dim runonWrds As String
    Dim splitoffWrd As String ' split-off word '
    Dim s As String
    Dim leftSide As String
    Dim rightSide As String
            
    WordsRS.index = "Text"
    CortexRS.index = "WordID"
    
    runonWrds = runOnWords
    wrdLen = Len(runonWrds)
    splitPoint = wrdLen - 1 ' if left part <> word(s) then reject splitoffWrd '
    
    If Right$("    " & runonWrds, 5) = "yness" Then
        ' ness is a word, so misspellings ending  '
        ' in yness are splitting on it, but it is '
        ' not a common word and "yness" is almost '
        ' always "iness" so I'm working around it.'
        splitPoint = wrdLen - 6
    End If
                
    Do
        splitoffWrd = Mid$(runonWrds, splitPoint)
        ' Skip past endings which are not words '
        ' (usually, though "el" is a train).    '
        If splitoffWrd = "ing" Or splitoffWrd = "ed" Or _
            splitoffWrd = "et" Or splitoffWrd = "es" Or _
            splitoffWrd = "el" And splitPoint > 2 _
        Then
            splitPoint = splitPoint - 1
            splitoffWrd = Mid$(runOnWords, splitPoint)
        End If
        
        If splitPoint > 1 Then leftSide = Left$(runonWrds, splitPoint - 1)
        
        WordsRS.Seek "=", splitoffWrd ' right part of (remaining part of) word '
        If Not WordsRS.NoMatch Then
            ' Make sure case matches: '
            Do While splitoffWrd <> WordsRS!Text And LCase$(splitoffWrd) = LCase$(WordsRS!Text)
                WordsRS.MoveNext
                If WordsRS.EOF Then Exit Do
            Loop
            
            ' Make sure the POS entry is a regular POS (noun, verb, etc.): '
            If splitoffWrd = WordsRS!Text Then
                CortexRS.Seek "=", WordsRS!Id
                If CortexRS.NoMatch Then
                    WordsRS.Seek "=", ";;;" ' Force a "WordsRS.NoMatch" for below. '
                Else
                    Do While Not (CortexRS!LinkID < 30130 Or CortexRS!LinkID = 30930 Or CortexRS!LinkID = 30940) And CortexRS!WordID = WordsRS!Id
                        ' 30000-30130 are common POS's; 30930=contraction; 30940=aux.verb. '
                        ' This screens out chemical symbols, acronyms, abbreviations,      '
                        ' prefixes, suffixes, letters, symbols, misspelled words, etc.     '
                        ' Change this code if you want any of these included in run-on's.  '
                        CortexRS.MoveNext
                        If CortexRS.EOF Then Exit Do
                    Loop
                    
                    If Not (CortexRS!LinkID < 30130 Or CortexRS!LinkID = 30930 Or CortexRS!LinkID = 30940) Or CortexRS!WordID <> WordsRS!Id Then
                        WordsRS.Seek "=", ";;;" '  ' Force a "WordsRS.NoMatch" for below. '
                    End If
                End If
            
            Else
                ' Case didn't match. Force a "Words.NoMatch" for next section. '
                WordsRS.Seek "=", ";;;"
            End If
        End If
                
        ' Check to see if it is a common word: '
        rank = 99999
        If Not WordsRS.NoMatch Then
            ' 5000-word frequency ranking '
            ' from WordFrequency.info     '
            'WordFreqRS.Index = "Word"
            'WordFreqRS.Seek "=", splitoffWrd
            
            'If Not WordFreqRS.NoMatch Then
            '    rank = WordFreqRS!ID
            'Else ' Use Words table: '
                WordsRS.Seek "=", splitoffWrd
                If Not WordsRS.NoMatch Then
                    If splitoffWrd <> WordsRS!Text Then
                        ' case doesn't match '
                        WordsRS.MoveNext
                    End If
                    If splitoffWrd = WordsRS!Text Then
                        rank = Val("" & WordsRS!FreqUsed) ' & "9999")
                    End If
                End If
            'End If
        
            ' Right part of word is a good word, '
            ' but use it only if the left part   '
            ' is also one or more good words:    '
            ' Example:  "grandfatherclock"       '
            ' First word found is "lock", but    '
            '   "grandfatherc" cannot be used.   '
            ' 2nd word found is "clock", which   '
            ' leaves "grandfather" on the left.  '
            ' Check for run-ons in "grandfather" '
            ' by recursively calling this routine.
            '   grandfat her                     '
            '   grandf at her                    '
            '   grand fat her   (list it)        '
            ' Once a good split is found, keep   '
            ' looking from the word to the left  '
            ' of the first word found in this    '
            ' loop ("fat", in this example).     '
            ' However, "grand" doesn't split, so '
            ' I won't bother to show it here.    '
            ' Now we return to "fat" and see if  '
            ' we can make any more words with it '
            ' at the end of a new word:          '
            '   gran dfat                        '
            '   gra ndfat                        '
            '   gr andfat                        '
            '   g randfat                        '
            '   grandfat                         '
            ' No new words were found with fat   '
            ' at the end, so we reject "her" and '
            ' return to "her" and try to make a  '
            ' new word with it at the end like   '
            ' we did with fat, above:            '
            '   grandfa ther                     '
            '   grandf ather                     '
            '   grand father      (list it)      '
            ' ... Again, "grand" doesn't split,  '
            ' so now we try to make a new word   '
            ' with "father" at the end:          '
            '   gran dfather                     '
            '   gra ndfather                     '
            '   gr andfather                     '
            '   g randfather                     '
            '   grandfather       (list it)      '
            ' Then go back to "clock" to see if  '
            ' it can be part of some larger word:'
            '   grandfathe rclock                '
            '   grandfath erclock                '
            '   grandfat herclock                '
            '   grandfa therclock                '
            '   grandf atherclock                '
            '   grand fatherclock                '
            '   gran dfatherclock                '
            '   gra ndfatherclock                '
            '   gr andfatherclock                '
            '   g randfatherclock                '
            ' We are now back to the original    '
            ' word, so the search is done.       '
            ' Note that each of the tests above  '
            ' is done by recursively calling     '
            ' the FindRunOns subroutine (below). '
            '                                    '
            ' The routine above does not find    '
            ' words in which an apostrophe or    '
            ' hyphen has been dropped, such as   '
            ' "sixoclock" or "runonwords".       '
            ' This test can be done by adding an '
            ' apostrophe and then a hyphen at    '
            ' each split point and testing again.'
            
            ' splitWords = good word(s) on the   '
            ' right of the original run-on text  '
            ' passed to this routine recursively.'
            ' This routine only operates on the  '
            ' the passed variable: runonWords    '
            '                                    '
            ' splitoffWrd = words which have     '
            ' already tested good, like "clock". '
            '                                    '
            ' leftSide = the letters to the      '
            '    left of the splitoffWrd.        '
            '                                    '
            ' Example:  "grandfatherclock"       '
            ' When splitoffWrd = "clock"  then   '
            ' leftSide = "grandfather".  Call    '
            '   FindRunOns leftSide, splitoffWrd '
            ' which this routine receives as the '
            ' variables runonWords & splitWords  '
            
            s = ""
            If Len(leftSide) = 1 Then
                If InStr("aAI", leftSide) = 0 Then rank = 9 '9999
            End If
            
            If rank < 4 Then '49999 Then ' ranking of splitoffWord '
                ' Use only common (<=19999), '
                '   less common (29999), and '
                '   rare (39999) words.      '
                WordsRS.Seek "=", leftSide
                If Not WordsRS.NoMatch Then
                  If WordsRS!FreqUsed < "4" Then
                    CortexRS.index = "WordID"
                    CortexRS.Seek "=", WordsRS!Id
                    If CortexRS.NoMatch And Right$(leftSide, 1) = "s" Then
                        ' Simple plurals (adding "s") are  '
                        ' often not entered in Cortex, so '
                        ' look for the singular form:      '
                        WordsRS.Seek "=", Left$(leftSide, Len(leftSide) - 1)
                        If Not WordsRS.NoMatch Then
                            CortexRS.Seek "=", WordsRS!Id
                        End If
                    End If
                    
                    If Not CortexRS.NoMatch Then
                        ' Bingo!!  When leftSide is a good word, '
                        ' add it and the previously split words  '
                        ' on its right to the suggestions list:  '
                        BidBaseFileViewer.lstSuggestions2.AddItem RTrim$(leftSide & " " & splitoffWrd & " " & splitWords)
                    End If
                  End If
                End If
                
                WordsRS.Seek "=", leftSide & "-" & splitoffWrd
                If Not WordsRS.NoMatch And splitWords <> "" Then
                    ' A hyphenated word was found: runonwords = run-on words '
                    ' but don't do just runon = run-on because already listed.
                    BidBaseFileViewer.lstSuggestions2.AddItem leftSide & "-" & splitoffWrd & " " & splitWords
                End If
                
                If splitPoint > 2 Then
                    int_Nested = int_Nested + 1
                    FindRunOns leftSide, Trim$(splitoffWrd & " " & splitWords)
                    ' In addition to passing the word split off in this recursion, '
                    ' we also pass the splitWords passed to this recursion, if any.'
                    ' Example: input="runonwords",                                 '
                    '  leftSide="run", splitoffWrd="on" & " " & splitWords="words" '
                ElseIf InStr("aAI", leftSide) > 0 Then
                    s = leftSide
                Else
                    WordsRS.Seek "=", runOnWords
                    If Not WordsRS.NoMatch Then
                        ' If no good split has been found,   '
                        ' then if runOnWords is a good word, '
                        ' return it:                         '
                        splitWords = runonWrds
                    End If
                End If
                
                If s <> "" Then
                    ' Left part is made up of good  '
                    ' words passed back recursively.'
                    splitWords = s & " " & splitoffWrd
                Else
                    splitPoint = splitPoint - 1
                End If
            Else
                splitPoint = splitPoint - 1
            End If
        Else
            splitPoint = splitPoint - 1
        End If
    Loop While splitPoint > 2
    If int_Nested > 0 Then int_Nested = int_Nested - 1
End Sub


Public Function LevDist(ByVal wrd As String, _
                        ByVal sug As String) As Integer
    ' Called by "Sub GetSuggestions". '
    
    ' Compute Levenshtein Distance. (From Wikipedia:) '
    ' The Levenshtein distance between two strings is '
    ' the minimum number of edits needed to transform '
    ' one string into the other, with the allowable   '
    ' edit operations being insertion, deletion, or   '
    ' substitution of a single character.             '
    ' The Levenshtein distance between "kitten" and   '
    ' "sitting" is 3, since the following three edits '
    ' are the minimum to change one into the other:   '
    ' 1.kitten > sitten (substitution of 's' for 'k') '
    ' 2.sitten > sittin (substitution of 'i' for 'e') '
    ' 3.sittin ? sitting (insert 'g' at the end).     '
    ' The smaller the LevDist, the more likely that   '
    ' sug is the correct replacement for wrd.         '
    
    Dim dist() As Integer ' Levenshtein matrix
    Dim sug_Len As Integer ' length of sug
    Dim wrd_Len As Integer ' length of wrd
    Dim wrd_i As Integer ' iterates through wrd
    Dim sug_i As Integer ' iterates through sug
    Dim wrd_Char As String ' ith character of wrd
    Dim sug_Char As String ' jth character of sug
    Dim chngs As Integer ' number of changes needed to make wrd = sug '
    Dim cell As Integer
    Dim trans As Integer
    Dim min As Integer
    Dim min2 As Integer
    Dim w As String
    Dim i As Long
    Dim j As Long
    Dim K As Long

    ' Ignore case. If user entered "pasover", '
    ' he would not be given "Passover".       '
    wrd = LCase$(wrd)
    sug = LCase$(sug)
    
    If InStr(sug, " ") Then
        LevDist = 1
        Exit Function
    End If

    wrd_Len = Len(wrd)
    sug_Len = Len(sug)
    If wrd_Len = 0 Then
        LevDist = sug_Len
        Exit Function
    End If
    If sug_Len = 0 Then
        LevDist = wrd_Len
        Exit Function
    End If

    ReDim dist(0 To wrd_Len, 0 To sug_Len) As Integer

    For wrd_i = 0 To wrd_Len
        dist(wrd_i, 0) = wrd_i
    Next

    For sug_i = 0 To sug_Len
        dist(0, sug_i) = sug_i
    Next

    For wrd_i = 1 To wrd_Len
        wrd_Char = Mid$(wrd, wrd_i, 1)
        For sug_i = 1 To sug_Len
            sug_Char = Mid$(sug, sug_i, 1)
            If wrd_Char = sug_Char Then
                chngs = 0
            Else
                chngs = 1
            End If
                        
            min = dist(wrd_i - 1, sug_i) + 1
            If dist(wrd_i, sug_i - 1) + 1 < min Then
                min = dist(wrd_i, sug_i - 1) + 1
            End If
            If dist(wrd_i - 1, sug_i - 1) + chngs < min Then
                min = dist(wrd_i - 1, sug_i - 1) + chngs
            End If
            dist(wrd_i, sug_i) = min
        
            ' Check for transposition of characters (teh = the): '
            If wrd_i > 1 And sug_i > 1 Then
                If wrd_Char = Mid$(sug, sug_i - 1, 1) And sug_Char = Mid$(wrd, wrd_i - 1, 1) Then
                    If dist(wrd_i, sug_i) >= dist(wrd_i - 2, sug_i - 2) + chngs Then
                        dist(wrd_i, sug_i) = dist(wrd_i - 2, sug_i - 2) + chngs
                        trans = 99
                    End If
                End If
            End If
        
            ' Check for "f" in place of "ph": '
            If wrd_Char = "f" And Mid$(sug, sug_i, 2) = "ph" Then
                w = LTrim$(Left$(" " & wrd, wrd_i)) & "ph" & RTrim$(Mid$(wrd & " ", wrd_i + 1))
                If w = sug Then
                    LevDist = 1
                    Exit Function
                End If
            End If
            
            ' "shun" in place of "tion" or "sion": '
            If Mid$(wrd & "    ", wrd_i, 4) = "shun" Then
                w = LTrim$(Left$(" " & wrd, wrd_i)) & "sion" & RTrim$(Mid$(wrd & " ", wrd_i + 4))
                If w = sug Then
                    LevDist = 1
                    Exit Function
                Else
                    w = LTrim$(Left$(" " & wrd, wrd_i)) & "tion" & RTrim$(Mid$(wrd & " ", wrd_i + 4))
                    If w = sug Then
                        LevDist = 1
                        Exit Function
                    End If
                End If
            End If
            
            ' "kel" in place of "cle" (debacle): '
            If Mid$(wrd & "    ", wrd_i, 3) = "kel" Then
                w = LTrim$(Left$(" " & wrd, wrd_i)) & "cle" & RTrim$(Mid$(wrd & " ", wrd_i + 3))
                If w = sug Then
                    LevDist = 1
                    Exit Function
                End If
            End If
            
            ' "ite" in place of "ight" (lite, nite): '
            If Mid$(wrd & "    ", wrd_i, 3) = "ite" Then
                w = Replace$(wrd, "ite", "ight")
                If w = sug Then
                    LevDist = 1
                    Exit Function
                End If
            End If
            
        
        Next
    Next

     ' Eye dialect edits, such as changing "ah" to '
    ' "er", are counted as 2 edits, reduce to 1.  '
    If dist(wrd_Len, sug_Len) > 1 Then
        If Right$(wrd, 2) = "ah" And Right$(sug, 2) = "er" Then
            ' mistah - eye dialect for  mister '
            dist(wrd_Len, sug_Len) = dist(wrd_Len, sug_Len) - 1
        End If
        
        i = InStr(wrd, "ee")
        w = wrd
        K = 0
        Do While i > 0
            j = Len(w)
            If i = 1 Then
                w = "i" & Mid$(w, 3) ' ees = is '
                K = K + 1
            ElseIf i = j - 2 Then
                Stop ' can't think of any examples '
            Else
                ' meester = mister '
                w = Left$(w, i - 1) & "i" & Mid$(w, i + 2)
                K = K + 1
            End If
            i = InStr(w, "ee")
        Loop
        If w = sug Then
            dist(wrd_Len, sug_Len) = dist(wrd_Len, sug_Len) - K
        End If
    End If
        
    LevDist = dist(wrd_Len, sug_Len)
    
    Erase dist
End Function


Private Function Minimum(ByVal a As Integer, _
                         ByVal b As Integer, _
                         ByVal c As Integer) As Integer
    ' Called by "Sub GetSuggestions". '
    Dim mi As Integer

    mi = a
    If b < mi Then mi = b
    If c < mi Then mi = c
    Minimum = mi
End Function


Public Function nGram(w1 As String, w2 As String) As Integer
    ' Called by "Sub GetSuggestions". '
    Dim gram(1, 50) As String
    Dim i As Integer
    Dim j As Integer
    Dim n As Integer
    Dim skipped As Integer

    If Abs(Len(w1) - Len(w2)) > 2 Then
        Exit Function
    End If

    For i = 1 To Len(w1)
        gram(0, i) = Mid$(w1, i, 2)
    Next

    For j = 1 To Len(w2)
        gram(1, j) = Mid$(w2, j, 2)
    Next

    n = 0
    i = 1
    j = 1
    Do
        If gram(0, i) = gram(1, j) Then
            If skipped < 2 Then
                n = n + 1
            End If
            If skipped > 0 Then
                skipped = skipped - 1
            End If
        ElseIf gram(0, i + 1) = gram(1, j) Then
            n = n + 1
            i = i + 1
            If skipped = 0 And gram(0, i - 1) <> gram(1, j - 1) Then
                skipped = skipped + 2
            Else
                skipped = skipped + 1
            End If
        ElseIf gram(0, i) = gram(1, j + 1) Then
            n = n + 1
            j = j + 1
            If skipped = 0 And gram(0, i - 1) <> gram(1, j - 1) Then
                skipped = skipped + 2
            Else
                skipped = skipped + 1
            End If
        End If
        i = i + 1
        j = j + 1
    Loop While i <= Len(w1) And j <= Len(w2)
    nGram = n
End Function


Public Function qGram(w1 As String, w2 As String) As Integer
    ' Called by "Sub GetSuggestions". '
    Dim gram(1, 50) As String
    Dim i As Integer
    Dim j As Integer
    Dim n As Integer
    Dim skipped As Integer

    If Abs(Len(w1) - Len(w2)) > 2 Then
        Exit Function
    End If

    For i = 1 To Len(w1)
        gram(0, i) = Mid$(w1, i, 1)
    Next

    For j = 1 To Len(w2)
        gram(1, j) = Mid$(w2, j, 1)
    Next

    i = 1
    j = 1
    n = 0
    Do
        If gram(0, i) = gram(1, j) Then
            'If 2+ letters skipped over to
            'find a match, skip an equal
            'number of matches:
            If skipped < 2 Then
                n = n + 1
            End If
            If skipped > 0 Then
                skipped = skipped - 1
            End If
        ElseIf gram(0, i + 1) = gram(1, j) Then
            n = n + 1
            i = i + 1
            skipped = skipped + 1
        ElseIf gram(0, i) = gram(1, j + 1) Then
            n = n + 1
            j = j + 1
            skipped = skipped + 1
        End If
        i = i + 1
        j = j + 1
    Loop While i <= Len(w1) And j <= Len(w2)
    qGram = n
End Function


Private Function Metaphone(w As String) As String
    Dim i As Long
    Dim c As String
    Dim c2 As String
    
    ' This routine makes adjustments to a word to '
    ' make it be spelled more the way it sounds   '
    ' before calculating its Soundex.             '
    ' This appears to be intended more for names  '
    ' than for regular words. The Metaphone 2     '
    ' algorithm is more precise, but again, it is '
    ' intended for use in differentiating names.  '
    ' My experience is that there are no hard and '
    ' fast rules for reliably computing the pro-  '
    ' nunuciation of regular words. Although most '
    ' spelling errors in typed text result from   '
    ' typos, not from using words which sound like'
    ' other words.                                '
    
    
    If InStr("ae gn kn pn wr ", Left$(w, 2)) > 0 Then w = Mid$(w, 2)
    
    If Right$(w, 2) = "mb" Then w = Left$(w, Len(w) - 1)
           
    w = Replace(w, "cia", "sha")
    w = Replace(w, "ci", "si")
    w = Replace(w, "ce", "se")
    w = Replace(w, "cy", "sy")
    w = Replace(w, "sci", "si")
    w = Replace(w, "sce", "se")
    w = Replace(w, "scy", "sy")
    w = Replace(w, "ch", "j")
    w = Replace(w, "c", "k")
    
    w = Replace(w, "kk", "k") ' line above changed ck to kk; second k silent in ck '
    
    w = Replace(w, "ph", "f") ' okay for "telephone" but not for "flophouse". '
    
    w = Replace(w, "q", "k")
    
    w = Replace(w, "sio", "sho")
    w = Replace(w, "sia", "sha")
    
    w = Replace(w, "tia", "sha")
    w = Replace(w, "tio", "sho")
    w = Replace(w, "tch", "j")
    
    w = Replace(w, "v", "f")
    
    i = InStr(2, w, "w")
    Do While i > 0
        If InStr("aeiou", Mid$(w & " ", i + 1, 1)) = 0 Then
            ' w not followed by a vowel '
            w = Left$(w, i - 1) & Mid$(w, i + 1)
        End If
        i = InStr(i + 2, w, "w")
    Loop
    
    w = Replace(w, "x", "ks")
    
    i = InStr(2, w, "y")
    Do While i > 0
        If InStr("aeiou", Mid$(w & " ", i + 1, 1)) = 0 Then
            ' y not followed by a vowel '
            w = Left$(w, i - 1) & Mid$(w, i + 1)
        End If
        i = InStr(i + 2, w, "y")
    Loop
    
    w = Replace(w, "z", "s")
    
    Metaphone = w
End Function


Public Function GetNextWord(ByVal StartSearch As Long) As String

    Dim LenText As Long
    Dim StartWord As Long
    Dim Ptr As Long
    Dim c As String 'individual character in Text
    Dim bln_SkipWord As Boolean
    Dim t As String 'full Text
    Dim w As String 'word

    Ptr = StartSearch - 1
    'Ptr normally starts as 0 because it
    'will be incremented below before anything
    'else is done.

    BidBaseFileViewer.t_Word = ""
    BidBaseFileViewer.t_Word.Refresh

With BidBaseFileViewer.Text2(1)
    If .SelText <> "" Then
        .SelColor = vbBlack
        .SelBold = False
    End If
    t = Trim$(.Text)
    LenText = Len(t)
    If LenText < 100 Then Exit Function 'keep it real
FindWord:
    Do 'Go through Text looking for a word:

        'Find start of word (next alpha character
        'or apostrophe, such as:  'til dawn.
        Do
            Ptr = Ptr + 1
            c = Mid$(t, Ptr, 1)
            SkipHTML t, c, Ptr, LenText
        Loop Until Ptr >= LenText Or _
                   c Like "[A-Z]" Or _
                   c Like "[a-z]" Or _
                   (c = "'" And Mid$(t, Ptr + 1, 1) <> " " And Mid$(t, Ptr + 1, 1) <> "<" And Ptr - StartSearch > 1)

        If Ptr >= LenText Then
            .SelLength = 0
            Exit Function
        End If

        'Find end of word (next non-alpha
        'character, except that a hypen or
        'apostrophe (e.g.: "isn't") in a word
        'is okay.
        StartWord = Ptr
        bln_SkipWord = False
        Do
            Ptr = Ptr + 1
            c = Mid$(t, Ptr, 1)
            If c Like "[A-Z]" Or _
               c Like "[0-9]" Then
                  bln_SkipWord = True
                  'But keep looking for EoW
            End If
        Loop While _
            Ptr = LenText Or _
            (c Like "[a-z]" Or _
             c Like "[A-Z]" Or _
             c Like "[0-9]" Or _
             c = "-" Or _
            (c = "'" And _
             Mid$(t + " ", Ptr + 1, 1) <> "s"))
        'The last two lines above ignore
        'the possesive "'s" on words, like
        '  "the car's tires"

        w = Mid$(t, StartWord, Ptr - StartWord)

        bln_SkipWord = IgnoreWord(w, Ptr, t)

    Loop While bln_SkipWord And Ptr < LenText

    'If Right$("  " & w, 2) = "s'" Then
    '    Ptr = Ptr - 1
        'Get rid of possesive like "cars' colors"
    'End If
    
    ' Get rid of single quotes: '
    If Right$(w, 1) = "'" Then
        Ptr = Ptr - 1
    End If
    If Left$(w, 1) = "'" Then
        StartWord = StartWord + 1
    End If

    If Ptr >= StartWord And w <> "com" Then
        If w = "com" Then
            If Mid$(t, StartWord - 1, 1) = "." Then ' .com '
                StartWord = Ptr + 1
                GoTo FindWord
            End If
        End If
        .SelStart = StartWord - 1
        .SelLength = Ptr - StartWord
        .SelColor = vbRed
        .SelBold = True
        ClearSpellCheckBox .SelText
        HighlightStart = .SelStart
        HighlightLen = .SelLength
    ElseIf Ptr < LenText - 100 Then
        Do
            Ptr = Ptr + 1
        Loop While Ptr < LenText And Mid$(t, Ptr, 1) <> ">"
        StartWord = Ptr + 1
        GoTo FindWord
    Else
        MsgBox "No more misspelled words found."
        CloseSpellCheck
    End If
End With

End Function


Private Function IgnoreWord( _
        ByVal str_Word, _
        ByVal Ptr As Long, _
        ByVal t As String) _
        As Boolean

    Dim i As Long
    Dim c$ 'character
    Dim c2$

    'Ignore bridge hands such as AKxxx-xx
    If InStr(str_Word, "xxx") > 0 Or InStr(str_Word, "xx") > 0 Or InStr(str_Word, "x-") > 0 Then
        IgnoreWord = True
        Exit Function
    End If

    'Ignore words with uppercase letters
    'or numbers inside them:
    For i = 2 To Len(str_Word)
        c$ = Mid$(str_Word, i, 1)
        If c$ Like "[A-Z]" Or _
           c$ Like "[0-9]" _
        Then
            IgnoreWord = True
            Exit Function
        End If
    Next

    If Len(str_Word) = 2 Then
        c2$ = Mid$(t, Ptr - 3, 1)
        'If the word is just "'s", left over
        'from a possesive word, skip it.
        'Likewise, any word ending in "-"
        If str_Word = "'s" Or str_Word Like "*-" Then
            IgnoreWord = True

        'Look for 1st, 2nd, 3rd, 4th, etc.
        ElseIf c2$ Like "[0-9]" Then
            If c2$ = "1" And str_Word = "st" Or _
               c2$ = "2" And str_Word = "nd" Or _
               c2$ = "3" And str_Word = "rd" Or _
               (c2$ Like "[4-9]" Or c2$ = "0") And _
                   str_Word = "th" _
            Then   'e.g.: 14th, 18th, 20th
                IgnoreWord = True
            End If
        End If
        If IgnoreWord Then Exit Function
    End If

    If int_LastIgnore > 0 Then
        'Check list of words user said
        'to ignore:
        For i = int_LastIgnore To 1 Step -1
            If str_Word = str_IgnoreWords(i) Then
                IgnoreWord = True
            End If
        Next
    End If
End Function


Public Sub OpenMySpellChecker()
    If Dir$(App.Path & "\ai.accdb") = "" Then
        MsgBox "The file ai.accdb must be in the same folder as this program." & vbCr & "It contains the information for performming spell checking." & vbCr & "See this program's documentation for more information."
        bln_CheckWord = False
        Exit Sub
    End If
    Set CortexWS = DBEngine.Workspaces(0)
    Set AICWordsWS = DBEngine.Workspaces(0)
    
    Set CortexDB = CortexWS.OpenDatabase(App.Path & "\ai.accdb")
    Set AICWordsDB = AICWordsWS.OpenDatabase(App.Path & "\AIC Words.accdb")
    
    Set CortexRS = CortexDB.OpenRecordset("Cortex")
    Set Cortex2RS = CortexDB.OpenRecordset("Cortex")
    Set Cortex3RS = CortexDB.OpenRecordset("Cortex")
    Set SyllRS = AICWordsDB.OpenRecordset("Syllables")
    Set PrnRS = AICWordsDB.OpenRecordset("PronunciationStandard")
    Set LinkTypeRS = CortexDB.OpenRecordset("LinkTypes")
    Set SpellRS = AICWordsDB.OpenRecordset("z_Misspelling-Wikipedia")
    Set NumbersRS = CortexDB.OpenRecordset("Numbers")
    Set WikiSpellRS = AICWordsDB.OpenRecordset("z_Misspelling-Wikipedia")
    Set WordFreqRS = AICWordsDB.OpenRecordset("WordFrequencyDotInfo")
    Set AICWordsWS = DBEngine.Workspaces(0)
    Set AICWordsDB = AICWordsWS.OpenDatabase("C:\Users\Public\WebPages\AIC\aic words.accdb")
    Set WordsRS = AICWordsDB.OpenRecordset("Words")
    
    With BidBaseFileViewer
        If Trim$(.Text2(1).Text) = "" Then
            Exit Sub
        End If
        'Make box visible or however you
        'want to display it:
        .BringOutSuggestionBox

    End With
End Sub


Public Sub MySpellCheckWord()
    Dim sndx

    bln_CheckWord = True
    OpenMySpellChecker
    If bln_CheckWord = False Then Exit Sub
    With BidBaseFileViewer
        .t_Word = Trim$(.Text2(1).SelText)
        If WordInDict(.t_Word) = False Then
            sndx = Soundex(.t_Word)
            GetSuggestions .t_Word, sndx
        Else
            MsgBox "The highlighted word is correct."
            CloseSpellCheck
        End If
    End With
End Sub


Public Sub ReplaceWord()
    Dim newSpelling As String
    Dim sndx As String
    Dim startPos As Long

With BidBaseFileViewer
    If .t_Replace = "" Or .t_Replace = "(No alternatives)" Then
        MsgBox "Select a new spelling first."
        .t_Replace.SetFocus
        Exit Sub
    End If

    If Trim$(.Text2(1).SelText) <> .t_Word Then
        MsgBox "Highlight the word to be fixed first."
        Exit Sub
    End If

    newSpelling = .t_Replace
    If Right$(.Text2(1).SelText, 1) = " " Then
        newSpelling = newSpelling + " "
    End If
    startPos = .Text2(1).SelStart
    .Text2(1).SelColor = vbBlack
    .Text2(1).SelBold = False
    .Text2(1).SelText = newSpelling

    If .t_Replace <> .lstSuggestions.List(.lstSuggestions.ListIndex) Then
        'User typed in a new word
        'so back up and check it too:
        .Text2(1).SelStart = startPos
        GetNextWord .Text2(1).SelStart
        If WordInDict(.t_Word) = False Then
            sndx = Soundex(.t_Word)
            GetSuggestions .t_Word, sndx
        Else
            .Text2(1).SelColor = vbBlack
            .Text2(1).SelBold = False
            .Text2(1).SelStart = startPos
            .Text2(1).SelLength = Len(.t_Word)
            If bln_CheckWord Then
                bln_CheckWord = False
                CloseSpellCheck
            Else
                SkipWord 0
            End If
        End If

    ElseIf bln_CheckWord Then
        CloseSpellCheck
    Else
        .Text2(1).SelLength = 0
        SkipWord 0
    End If
End With
End Sub


Private Function SkipHTML(ByVal t As String, _
                           c As String, _
                           Ptr As Long, _
                           TxtLen As Long)
    Dim EoW As Long
    Dim i As Integer

    Do While c = "<" And Ptr < TxtLen
        EoW = InStr(Ptr + 1, t, ">")
        If EoW > 0 Then
            Ptr = EoW
        End If
        Ptr = Ptr + 1
        c = Mid$(t, Ptr, 1)
    Loop 'in case 2+ HTML codes in a row

    Do While c = "&" And Mid$(t, Ptr + 1, 1) <> " " And Ptr < TxtLen
        EoW = InStr(Ptr + 1, t, ";")
        If EoW > 0 Then
            c = Mid$(t, Ptr + 1, 1)
            If c Like "[a-z]" Then
                Ptr = EoW
            End If
        End If
        Ptr = Ptr + 1
        c = Mid$(t, Ptr, 1)
    Loop
    
    SkipHTML = Ptr
End Function


Public Sub SkipWord(ByVal index)
    Dim TxtLen As Long
    Dim sndx As String

With BidBaseFileViewer
    'Keep track of words to skip/ignore:
    If index = 1 Then 'Skip all. 0=skip this time only.
        int_LastIgnore = int_LastIgnore + 1
        str_IgnoreWords(int_LastIgnore) = .t_Word
    End If

    TxtLen = Len(.Text2(1).Text)
    Do
        GetNextWord .Text2(1).SelStart + .Text2(1).SelLength + 1
        If .frmSuggestions.Visible = False Then
            Exit Sub
        ElseIf .Text2(1).SelText = "" Or .Text2(1).SelStart >= TxtLen Then
            Exit Do
        End If
        If WordInDict(.t_Word) = False Then
            sndx = Soundex(.t_Word)
            GetSuggestions .t_Word, sndx
        Else
            .t_Word = ""
        End If
    Loop While .t_Word = "" And .Text2(1).SelStart < TxtLen

    If Trim$(.t_Word) = "" Then
        CloseSpellCheck
    Else
        .t_Replace.SetFocus
    End If
End With
End Sub


Public Function Soundex(ByVal wordstr _
            As String) As String
    Dim str_Word As String
    Dim i As Long
    Dim c As String
    Dim s As String
    Dim d As String
    Dim f As String
    Dim let1 As String
    Dim wrd As String
    Dim metaph As String
    
    ' 1. Encode the letters, starting with the 2nd letter.    '
    ' 2. If two adjacent letters have the same soundex code,  '
    '      treat them as one.                                 '
    ' 3. If two consonants are separated by a vowel or Y, use '
    '      both consonants.                                   '
    ' 4. If two consonants are separated by H or W, treat     '
    '      them as one. (I.e. rule 3 applies.)                '
    
    str_Word = UCase$(Trim$(wordstr))
    If str_Word = "" Then Exit Function

    ' Get rid of non-alpha characters: '
    ' (e.g.:  o'clock  ->  oclock)     '
    For i = 1 To Len(str_Word)
        c = Mid(str_Word, i, 1)
        f = c
        If InStr("�����ū", c) > 0 Then
            f = "A"
        ElseIf c = "�" Then
            f = "C"
        ElseIf InStr("����", c) > 0 Then
            f = "E"
        ElseIf InStr("����", c) > 0 Then
            f = "I"
        ElseIf c = "�" Then
            f = "N"
        ElseIf InStr("�����", c) > 0 Then
            f = "O"
        ElseIf InStr("����", c) > 0 Then
            f = "U"
        ElseIf c = "�" Then
            f = "Y"
        End If
        If c <> f Then Mid$(str_Word, i, 1) = f
        
        If (Not (c Like "[A-Z]")) Then
            str_Word = Replace(str_Word, c, " ")
        End If
    Next i
    str_Word = Replace$(str_Word, " ", "")

    If str_Word = "" Then Exit Function

    ' Change starting letters to actual sounds: '
    s = Left$(str_Word, 2)
    If s = "PS" Or s = "PN" Or s = "KN" Or s = "GN" Or s = "WR" Then
        str_Word = Mid(str_Word, 2)
    ElseIf Left$(str_Word, 3) = "WHO" Then
        str_Word = "H" & Mid$(str_Word, 3)
    ElseIf s = "WH" Then
        str_Word = "W" & Mid$(str_Word, 3)
    ElseIf s = "PH" Then
        str_Word = "F" & Mid$(str_Word, 3)
    ElseIf Left$(str_Word, 1) = "X" Then
        str_Word = "Z" & Mid$(str_Word, 2)
    End If

    ' Metaphone changes: '
    ' When swapping letters for numbers, "c" '
    ' is treated as a sibilant, not as a "k".'
    str_Word = Replace$(str_Word, "STLE", "SEL") ' whistle, castle, wrestle, gristle - the t is silent '
    str_Word = Replace$(str_Word, "SCLE", "SEL") ' muscle - the c is silent '
    str_Word = Replace$(str_Word, "CK", "K")   ' rack, flock, trick, check - the c is silent '
    str_Word = Replace$(str_Word, "CT", "KT")  ' doctor, reactor, practice - the c is hard '
    str_Word = Replace$(str_Word, "SCI", "SI") ' science - the c is silent '
    str_Word = Replace$(str_Word, "SCE", "SE") ' scene - the c is silent '
    str_Word = Replace$(str_Word, "SCY", "SY")
    str_Word = Replace$(str_Word, "SC", "SK")  ' scary, disco, rascal - the c is hard '
    str_Word = Replace$(str_Word, "DGE", "J")  ' edge '
    str_Word = Replace$(str_Word, "DGY", "JE") ' edgy '
    str_Word = Replace$(str_Word, "DGI", "JI") ' edginess '
    str_Word = Replace$(str_Word, "TIA", "SHA")
    str_Word = Replace$(str_Word, "TIO", "SHO")
    str_Word = Replace$(str_Word, "TCH", "CH")
    
    If Right$(str_Word, 2) = "GN" Then str_Word = Left$(str_Word, Len(str_Word) - 2) & "N"  ' sign '
    If Right$(str_Word, 4) = "GNED" Then str_Word = Left$(str_Word, Len(str_Word) - 4) & "ND"
    If Right$(str_Word, 5) = "GNING" Then str_Word = Left$(str_Word, Len(str_Word) - 5) & "NING"
    If Right$(str_Word, 2) = "IC" Then str_Word = Left$(str_Word, Len(str_Word) - 2) & "IK"  ' rustic, fantastic '
    
    i = InStr(str_Word, "W")
    Do While i > 0
        If InStr("AEIOU", Mid$(str_Word & " ", i + 1, 1)) = 0 Then
            ' W not followed by a vowel is silent. '
            If i > 1 Then
                str_Word = RTrim$(Left$(str_Word, i - 1) & Mid$(str_Word & " ", i + 1))
            Else
                str_Word = Mid$(str_Word, 2)
            End If
        End If
        i = InStr(i + 1, str_Word, "W")
    Loop

    ' Metaphone says that G is silent in GH, '
    ' but the GH becomes F in LAUGHTER.      '

    ' Change letters to codes,  '
    ' starting with 2nd letter: '
    For i = 2 To Len(str_Word)
        d = Mid$(str_Word, i, 1)
        If InStr("AEIOUHWY", d) > 0 Then
            d = "0"  ' zero, not uppercase "o". '
        ElseIf InStr("BFPV", d) > 0 Then
            d = "1"
        ElseIf InStr("GJKQ", d) > 0 Then
            d = "2"
        ElseIf InStr("CSXZ", d) > 0 Then
            ' Split these from last line because '
            ' GJKQ are hard sounds and CSXZ are  '
            ' sibilants ("s" sounding), other    '
            ' that the adjustments to C combos   '
            ' made above.                        '
            d = "7"
        ElseIf InStr("DT", d) > 0 Then
            d = "3"
        ElseIf InStr("L", d) > 0 Then
            d = "4"
        ElseIf InStr("MN", d) > 0 Then
            d = "5"
        ElseIf InStr("R", d) > 0 Then
            d = "6"
        Else
            If d <> "-" Then Stop
            d = ""
        End If
        Mid(str_Word, i, 1) = d
    Next
    
    wrd = ""
    ' Remove repeating codes:  50773 -> 5073 '
    For i = 1 To Len(str_Word)
        If Mid(str_Word, i, 1) <> _
            Mid(str_Word & " ", i + 1, 1) _
        Then
            wrd = wrd + Mid(str_Word, i, 1)
        End If
    Next
    If str_Word = "" Then Exit Function

    ' Get rid of vowels: '
    str_Word = Replace(wrd, "0", "")

    ' For longwords, save an extra digit: '
    'If Len(WordStr) > 6 Then i = 5 Else i = 4
    str_Word = Left$(str_Word & "0000", 4)
    
    Soundex = str_Word
End Function


Public Function WordInDict( _
        ByVal str_Word As String) _
        As Boolean

    Dim pre2$, pre3$, hyph As Long, w1$

    str_Word = Trim$(str_Word)
    If Len(str_Word) < 2 Then
        WordInDict = True
        Exit Function
    End If

    'Look for the word:
    With WordsRS
        .index = "Text"
        .Seek "=", str_Word

        If .NoMatch Then
            pre2$ = Left$(str_Word, 2)
            pre3$ = Left$(str_Word, 3)
            'If both halves of a hyphenated word,
            'such as "hard-coded" or "point-based",
            'are in the dictionary, then accept the
            'word, even though the combination may
            'not be in the dictionary:
            hyph = InStr(str_Word, "-")
            If hyph > 1 And _
               hyph < Len(str_Word) _
            Then
                w1$ = Left$(str_Word, hyph - 1)
                .Seek "=", w1$
                If .NoMatch = False Then
                    w1$ = Mid$(str_Word, hyph + 1)
                    .Seek "=", w1$
                    If .NoMatch = False Then
                        WordInDict = True
                        'At this point, both halves
                        'have been found, so OK it.
                    Else
                        'First half is okay, but
                        'second half not found:
                        BidBaseFileViewer.t_Word = ""
                        With BidBaseFileViewer.Text2(1)
                            .SelColor = vbBlack
                            .SelBold = False
                            .SelStart = .SelStart + hyph
                            .SelLength = 0
                        End With
                    End If
                Else
                    'First half not found:
                    If Len(str_Word) - hyph = 1 Then
                        'Probably Ctrl-x, Shift-x, Alt-x, etc.
                        BidBaseFileViewer.t_Word = w1$
                        With BidBaseFileViewer.Text2(1)
                            .SelColor = vbBlack
                            .SelBold = False
                            .SelLength = hyph - 1
                            .SelColor = vbRed
                            .SelBold = True
                        End With
                    End If
                End If
            ElseIf pre2$ = "un" Or pre2$ = "re" Or pre2$ = "de" Then
                'A lot of words are made by adding "un"
                '("unfasten"), or "re" ("reconnect") or
                '"de" ("deselect") to the front.
                'Remove the prefix and check:
                w1$ = Trim$(Mid$(str_Word, 3))
                If w1$ <> "" Then
                    .Seek "=", w1$
                    If .NoMatch = False Then
                        WordInDict = True
                    End If
                End If
            ElseIf pre3$ = "non" Or pre3$ = "pre" Then
                'eg: "nonresponsive":
                w1$ = Trim$(Mid$(str_Word, 4))
                If w1$ <> "" Then
                    .Seek "=", w1$
                    If .NoMatch = False Then
                        WordInDict = True
                    End If
                End If
            End If
        Else
            WordsRS.index = "Text"
            WordsRS.Seek "=", str_Word
            ' Case is ignored. '
            If .NoMatch Then
                Exit Function
            Else
                ' Make sure the text in the Words table is good. '
                CortexRS.index = "WordID"
                CortexRS.Seek "=", WordsRS!Id
                If Not CortexRS.NoMatch Then
                    Do While CortexRS!WordID = WordsRS!Id And (CortexRS!LinkID < 30000 Or CortexRS!LinkID > 30210)
                        CortexRS.MoveNext
                        If CortexRS.EOF Then
                            CortexRS.Seek "=", WordsRS!Id
                            Exit Do
                        End If
                    Loop
                    If CortexRS!WordID <> !Id Or CortexRS!LinkID < 30000 Or CortexRS!LinkID > 30210 Then
                        Exit Function
                    End If
                End If
            End If
            WordInDict = True
        End If
    End With
End Function


Public Sub WordSpellcheckDoc()
    'Use MS Word to check document (RTB.Text).
    'Reminder: Word is SLOW to load.
    Dim speller As Object
    Dim txt As String
    Dim new_txt As String
    Dim pos As Integer
    Dim ans As Integer
    Dim xx, m$, r

    On Error GoTo OpenError
    Screen.MousePointer = vbHourglass
    xx = DoEvents()
    'Debug.Print Timer
    Set speller = CreateObject("Word.Basic")
    'Debug.Print Timer
    Screen.MousePointer = 0
    On Error GoTo 0

    With speller
        .FileNew
        .Insert BidBaseFileViewer.Text2(1).Text
        .ToolsSpelling
        .EditSelectAll
        txt = .Selection()
        .FileExit 2
    End With

    If Right$(txt, 1) = vbCr Then
        txt = Left$(txt, Len(txt) - 1)
    End If
    new_txt = ""
    pos = InStr(txt, vbCr)
    Do While pos > 0
        new_txt = new_txt & Left$(txt, pos - 1) & vbCrLf
        txt = Right$(txt, Len(txt) - pos)
        pos = InStr(txt, vbCr)
    Loop
    new_txt = new_txt & txt

    m$ = "Save all corrections to disk?" & vbCr & _
         "(No = save to display, not to disk." & vbCr & _
         " Cancel = discard all corrections.)"
    ans = MsgBox(m$, vbYesNoCancel)
    If ans <> vbCancel Then
        BidBaseFileViewer.Text2(1).Text = new_txt
        If r = vbYes Then
            'BidBaseFileViewer.mSave_Click 'your menu item to save to disk
        End If
    End If
Exit Sub

OpenError:
    MsgBox "Error" & Str$(Error.Number) & _
        " opening Word." & vbCrLf & _
        Error.Description
End Sub


