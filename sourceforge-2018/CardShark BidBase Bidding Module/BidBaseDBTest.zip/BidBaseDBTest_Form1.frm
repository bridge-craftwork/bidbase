VERSION 5.00
Begin VB.Form BidMan 
   BackColor       =   &H00C0FFC0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "BidBase BidMan"
   ClientHeight    =   4815
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   9690
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4815
   ScaleWidth      =   9690
   StartUpPosition =   3  'Windows Default
   Begin VB.ComboBox cmb_ScoringMethod 
      Height          =   315
      ItemData        =   "BidBaseDBTest_Form1.frx":0000
      Left            =   360
      List            =   "BidBaseDBTest_Form1.frx":000D
      TabIndex        =   20
      Top             =   2700
      Width           =   1740
   End
   Begin VB.CommandButton cmd_Quit 
      Caption         =   "&Quit"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   390
      Left            =   2760
      TabIndex        =   18
      Top             =   1350
      Width           =   1695
   End
   Begin VB.TextBox t_Disclosure 
      BackColor       =   &H00C0FFFF&
      Height          =   4320
      Left            =   4665
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   15
      Top             =   420
      Width           =   4890
   End
   Begin VB.CheckBox ck_GetDiscl 
      BackColor       =   &H00C0FFC0&
      Caption         =   "Get Disclosures"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   345
      TabIndex        =   14
      Top             =   4200
      Value           =   1  'Checked
      Width           =   1740
   End
   Begin VB.TextBox Text1 
      Height          =   300
      Index           =   2
      Left            =   330
      TabIndex        =   3
      Top             =   3765
      Width           =   1725
   End
   Begin VB.CommandButton cmd_Cancel 
      Caption         =   "&Cancel Search"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   390
      Left            =   2760
      TabIndex        =   5
      Top             =   795
      Width           =   1695
   End
   Begin VB.CommandButton cmd_GetBid 
      Caption         =   "&Get Bid For Hand"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   390
      Left            =   2760
      TabIndex        =   4
      Top             =   255
      Width           =   1695
   End
   Begin VB.TextBox Text1 
      Height          =   300
      Index           =   0
      Left            =   360
      TabIndex        =   0
      Text            =   "AKT432-T3-JT3-42"
      Top             =   480
      Width           =   1725
   End
   Begin VB.TextBox Text1 
      Height          =   300
      Index           =   1
      Left            =   345
      TabIndex        =   1
      Top             =   1170
      Width           =   1725
   End
   Begin VB.ComboBox cmb_Vul 
      Height          =   315
      ItemData        =   "BidBaseDBTest_Form1.frx":0021
      Left            =   360
      List            =   "BidBaseDBTest_Form1.frx":0031
      TabIndex        =   2
      Top             =   1905
      Width           =   1740
   End
   Begin VB.Label Label1 
      BackColor       =   &H00C0FFC0&
      Caption         =   "Scoring Method:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Index           =   7
      Left            =   360
      TabIndex        =   19
      Top             =   2430
      Width           =   1770
   End
   Begin VB.Label Label1 
      BackColor       =   &H00C0FFC0&
      Caption         =   "Disclosure"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   6
      Left            =   4680
      TabIndex        =   17
      Top             =   195
      Width           =   1110
   End
   Begin VB.Label Label1 
      BackColor       =   &H00C0FFC0&
      Caption         =   "Bid:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Index           =   5
      Left            =   3225
      TabIndex        =   16
      Top             =   1905
      Width           =   1110
   End
   Begin VB.Line Line1 
      X1              =   2445
      X2              =   2445
      Y1              =   30
      Y2              =   4900
   End
   Begin VB.Label Label1 
      BackColor       =   &H00C0FFC0&
      Caption         =   "Show analysis for bid(s) or ALL:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   4
      Left            =   330
      TabIndex        =   13
      Top             =   3345
      Width           =   1560
   End
   Begin VB.Label lbl_Error 
      Alignment       =   2  'Center
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   240
      Index           =   1
      Left            =   3495
      TabIndex        =   12
      Top             =   2805
      Width           =   270
   End
   Begin VB.Label lbl_Error 
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   1620
      Index           =   0
      Left            =   2565
      TabIndex        =   11
      Top             =   3090
      Width           =   1995
   End
   Begin VB.Label Label1 
      BackColor       =   &H00C0FFC0&
      Caption         =   "Error #    :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Index           =   3
      Left            =   2820
      TabIndex        =   10
      Top             =   2835
      Width           =   1110
   End
   Begin VB.Label Label1 
      BackColor       =   &H00C0FFC0&
      Caption         =   "Hand:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Index           =   0
      Left            =   360
      TabIndex        =   9
      Top             =   225
      Width           =   1215
   End
   Begin VB.Label Label1 
      BackColor       =   &H00C0FFC0&
      Caption         =   "Prior Calls::"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Index           =   1
      Left            =   345
      TabIndex        =   8
      Top             =   930
      Width           =   1725
   End
   Begin VB.Label lbl_Bid 
      Alignment       =   2  'Center
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   24
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   600
      Left            =   3135
      TabIndex        =   7
      Top             =   2145
      Width           =   1125
   End
   Begin VB.Label Label1 
      BackColor       =   &H00C0FFC0&
      Caption         =   "Vulnerability:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Index           =   2
      Left            =   360
      TabIndex        =   6
      Top             =   1650
      Width           =   1020
   End
End
Attribute VB_Name = "BidMan"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private NewBid As BidBaseDB.Bidder

Private Sub cmd_Cancel_Click()
    NewBid.CancelSearch = True
End Sub

Private Sub cmd_GetBid_Click()
    Dim b As String
    Dim d As String
    
    lbl_Bid.Caption = ""
    lbl_Error(0) = ""
    lbl_Error(1) = ""
    t_Disclosure = ""
    
    With NewBid
        ' Submit specs to DLL: '
        .DBPathAndName = App.Path + "\BidBase.ACCDB"
        .PlayersHand = Trim$(Text1(0))
        .PriorCalls = Trim$(Text1(1))
        .Vul = Trim$(Left$(cmb_Vul & " ", 1))
        .BidToAnalyze = Trim$(Text1(2))
        .GetDisclosures = (ck_GetDiscl.Value <> 0)
        .ScoringMethod = Trim$(Left$(cmb_ScoringMethod & " ", 1))
        
        ' The following 2 flags are normally not used '
        ' by programs other than the BidBase Editor:  '
        '                                             '
        ' .TestEntry = ID# of an entry being tested.  '
        ' .CheckAllPcts = the bidder normally ignores '
        '        entries with Pct_Used = "x" or "0".  '
        '        This flag says to check them too.    '
        '        Again, this is used just for testing '
        '        the database, not by playing pgms.   '
        
        cmd_Cancel.Enabled = True
        cmd_GetBid.Enabled = False
        
        'Get bid:
        b = .Bid
        d = .Disclosure
    
        If b = "" Then
            lbl_Error(1) = .ErrCode
            lbl_Error(0) = .ErrMsg
        Else
            lbl_Bid.Caption = b
            If d <> "" Then t_Disclosure = d
        End If
    End With
    
    cmd_GetBid.Enabled = True
    cmd_Cancel.Enabled = False
End Sub

Private Sub cmd_Quit_Click()
    Form_Unload 0
End Sub

Private Sub Form_Load()
  Set NewBid = New BidBaseDB.Bidder
End Sub

Private Sub Form_Unload(Cancel As Integer)
  Set NewBid = Nothing
  End
End Sub

Private Sub Text1_Change(index As Integer)
    If lbl_Bid.Caption <> "" Or lbl_Error(0) <> "" Then
        lbl_Bid.Caption = ""
        lbl_Error(0) = ""
        lbl_Error(1) = ""
        t_Disclosure = ""
    End If
End Sub

Private Sub Text1_GotFocus(index As Integer)
    Text1(index).SelStart = 0
    Text1(index).SelLength = 99
End Sub

